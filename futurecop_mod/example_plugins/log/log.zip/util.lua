function log(msg)
  print("[log] " .. msg)
end